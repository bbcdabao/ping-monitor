<template>
  <div>
    <el-card class="custom-shadow mgb20" shadow="hover">
      <template #header>
        <div class="content-title">日前交易</div>
      </template>
      <div class="this-card mgb20">
      </div>
    </el-card>
  </div>
</template>
<script setup lang="ts">

</script>
<style scoped>
.this-card {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
</style>