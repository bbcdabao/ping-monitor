<template>
  <div>
    <el-card class="custom-shadow mgb20" shadow="hover">
      <template #header>
        <div class="content-title">用户信息</div>
      </template>
      <div class="this-card mgb20">
        <el-form :model="userinfo" :rules="userinfoRules" ref="userinfoRef" label-width="80px">
          <el-form-item :label="$t('user')" prop="username" style="width: 250px;">
            <el-input v-model="userinfo.username" disabled />
          </el-form-item>
          <el-form-item :label="$t('phoneNum')" prop="phone" style="width: 250px;">
            <el-input v-model="userinfo.phone" :disabled="!userinfoEdit" />
          </el-form-item>
          <el-form-item :label="$t('serviceTimeRange')" prop="timerange" style="width: 250px;">
            <el-input v-model="userinfo.timerange" :disabled="!userinfoEdit"/>
          </el-form-item>
          <el-form-item style="width: 220px;">
            <div v-if="userinfoEdit">
              <el-button style="margin-top: 0px;" type="primary" @click="userinfoSubmit">{{ $t('submitInfo') }}</el-button>
              <el-button style="margin-top: 0px;" type="primary" @click="clsUserinfoEdit">{{ $t('cancelInfo') }}</el-button>
            </div>
            <div v-else>
              <el-button style="margin-top: 0px;" type="primary" @click="setUserinfoEdit">{{ $t('editInfo') }}</el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-card>
    <el-card class="custom-shadow mgb20" shadow="hover">
      <template #header>
        <div class="content-title">角色列表</div>
      </template>
      <div class="this-card mgb20">
        <el-table :data="roleinfoList" height="100%" style="width: 100%">
          <el-table-column prop="name" label="名称" width="220" />
          <el-table-column prop="identity" label="角色" width="220" />
          <el-table-column label="操作">
            <template #default="scope">
              <el-button size="small" type="primary" @click="enterRole(scope.row)">进入角色</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
    <el-card class="custom-shadow mgb20" shadow="hover">
      <template #header>
        <div class="content-title">创建角色</div>
        <el-switch style="margin-left: auto;" v-model="roleinfoSwitch" />
      </template>
      <div class="this-card mgb20" v-if="roleinfoSwitch">
        <el-form :model="roleinfo" :rules="roleinfoRules" ref="roleinfoRef" label-width="80px">
          <el-form-item :label="$t('roleName')" prop="name" style="width: 250px;">
            <el-input v-model="roleinfo.name" />
          </el-form-item>
          <el-form-item :label="$t('roleType')" prop="identity" style="width: 250px;">
            <el-select v-model="roleinfo.identity" placeholder="选择校色">
              <el-option
                v-for="item in identityList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('status')" prop="status" style="width: 250px;">
            <el-radio-group v-model="roleinfo.status">
              <el-radio :label="true">{{ $t('active') }}</el-radio>
              <el-radio :label="false">{{ $t('noactive') }}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item style="width: 220px;">
            <div>
              <el-button style="margin-top: 0px;" type="primary" @click="roleinfoSubmit">{{ $t('submitInfo') }}</el-button>
              <el-button style="margin-top: 0px;" type="primary" @click="roleinfoClearn">{{ $t('clearn') }}</el-button>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </el-card>
  </div>
</template>
<script setup lang="ts">

import { onMounted, ref } from 'vue';
import { getRoleList } from '@/api'
import { useRouter } from 'vue-router';
import { ElButton, ElForm, ElFormItem, ElInput, ElMessage, FormRules } from 'element-plus';

const userinfoEdit = ref(false);
const setUserinfoEdit = () => {
  userinfoEdit.value = true;
};
const clsUserinfoEdit = () => {
  userinfoEdit.value = false;
};

const username: string | null = localStorage.getItem('vuems_name');

const userinfoRef = ref(null);

const userinfo = ref({
  username: username,
  phone: '12345678900',
  timerange: '2025~2026'
});

const userinfoRules = ref<FormRules>({
  phone: [
    { 
      required: true,
      message: '请输入手机号',
      trigger: 'blur'
    },
    {
      pattern: /^1[3-9]\d{9}$/,
      message: '请输入正确的11位手机号',
      trigger: 'blur'
    }
  ]
});

const userinfoSubmit = () => {
  userinfoRef.value.validate((valid: boolean) => {
    if (valid) {
        ElMessage.success('success');
    } else {
        ElMessage.error('fail');
    }
  })
};

const roleinfoSwitch = ref(false);

const roleinfoRef = ref(null);

const roleinfo = ref({
  name: '',
  identity: '',
  status: true
});

const roleinfoRules = ref<FormRules>({
});

const roleinfoSubmit = () => {
  roleinfoRef.value.validate((valid: boolean) => {
    if (valid) {
        ElMessage.success('success');
    } else {
        ElMessage.error('fail');
    }
  })
};

const roleinfoClearn = () => {
  roleinfo.value = {
    name: '',
    identity: '',
    status: true
  };
}

const identityList = [
  { value: 'fire', label: '火电' },
  { value: 'sale', label: '交易' },
  { value: 'newe', label: '新能源' },
  { value: 'ener', label: '储能' }
]

const roleinfoList = ref([]);

const router = useRouter();
const enterRole = (roleinfo) => {
  router.push('/daytrade');
}

onMounted(() => {
  getRoleList()
  .then(res => {
    roleinfoList.value = res.data.list;
  })
  .catch(err => {
    console.error('请求失败', err);
  });
});

</script>
<style scoped>
.this-card {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
</style>