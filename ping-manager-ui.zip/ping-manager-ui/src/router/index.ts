import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router';
import Home from '../views/home.vue';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/userinfo',
  },
  {
    path: '/',
    name: 'Home',
    component: Home,
    children: [
      {
        path: '/userinfo',
        name: 'userinfo',
        meta: { title: 'userinfo', noAuth: false },
        component: () => import('../views/pages/userinfo.vue'),
      },
      {
        path: '/retailsall',
        name: 'retailsall',
        meta: { title: 'retailsall', noAuth: false },
        component: () => import('../views/pages/retailsall.vue'),
      },
      {
        path: '/daytrade',
        name: 'daytrade',
        meta: { title: 'daytrade', noAuth: false },
        component: () => import('../views/pages/daytrade.vue'),
      },
      {
        path: '/daytrade-sale',
        name: 'daytrade-sale',
        meta: { title: 'daytrade-sale', noAuth: false },
        component: () => import('../views/pages/daytrade.vue'),
      },
      {
        path: '/longtrade',
        name: 'longtrade',
        meta: { title: 'longtrade', noAuth: false },
        component: () => import('../views/pages/longtrade.vue'),
      },
      {
        path: '/longtrade-sale',
        name: 'longtrade-sale',
        meta: { title: 'longtrade-sale', noAuth: false },
        component: () => import('../views/pages/longtrade.vue'),
      },
      {
        path: '/tradesettl',
        name: 'tradesettl',
        meta: { title: 'tradesettl', noAuth: false },
        component: () => import('../views/pages/tradesettl.vue'),
      },
      {
        path: '/tradesettl-sale',
        name: 'tradesettl-sale',
        meta: { title: 'tradesettl-sale', noAuth: false },
        component: () => import('../views/pages/tradesettl.vue'),
      },
      {
        path: '/tradelists',
        name: 'tradelists',
        meta: { title: 'tradelists', noAuth: false },
        component: () => import('../views/pages/tradelists.vue'),
      },
      {
        path: '/tradelists-sale',
        name: 'tradelists-sale',
        meta: { title: 'tradelists-sale', noAuth: false },
        component: () => import('../views/pages/tradelists.vue'),
      },
      {
        path: '/spotsinfos',
        name: 'spotsinfos',
        meta: { title: 'spotsinfos', noAuth: false },
        component: () => import('../views/pages/spotsinfos.vue'),
      },
      {
        path: '/spotsinfos-sale',
        name: 'spotsinfos-sale',
        meta: { title: 'spotsinfos-sale', noAuth: false },
        component: () => import('../views/pages/spotsinfos.vue'),
      },
      {
        path: '/theme',
        name: 'theme',
        meta: { title: 'theme', noAuth: false },
        component: () => import('../views/pages/theme.vue'),
      },
    ],
  },
  {
    path: '/login',
    meta: { title: 'login', noAuth: true },
    component: () => import('../views/pages/login.vue'),
  },
  {
    path: '/404',
    meta: { title: 'cannotfound', noAuth: true },
    component: () => import('../views/pages/404.vue'),
  },
  {
    path: '/:path(.*)',
    redirect: '/404',
  },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  NProgress.start();
  const role = localStorage.getItem('vuems_name');
  if (!role && to.meta.noAuth !== true) {
    next('/login');
  } else {
    next();
  }
});

router.afterEach(() => {
  NProgress.done();
});

export default router;