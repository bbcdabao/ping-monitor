/**
 * Copyright 2025 bbcdabao Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { defineStore } from 'pinia';
import i18n from '@/i18n';

export const useSidebarStore = defineStore('sidebar', {
  state: () => {
    const tradMenu = [
      {
        itemname: 'goback',
        itemicon: 'CaretLeft',
        route: '/userinfo',
      },
      {//日前交易
        itemname: 'daytrade',
        itemicon: 'Management',
        route: '/daytrade',
      },
      {//中长期交易
        itemname: 'longtrade',
        itemicon: 'Ticket',
        route: '/longtrade',
      },
      {//交易结算
        itemname: 'tradesettl',
        itemicon: 'Checked',
        route: '/tradesettl',
      },
      {//交易排名
        itemname: 'tradelists',
        itemicon: 'TrendCharts',
        route: '/tradelists',
      },
      {//现货披露信息
        itemname: 'spotsinfos',
        itemicon: 'List',
        route: '/spotsinfos',
      }
    ];
    const saleMenu = [
      {
        itemname: 'goback',
        itemicon: 'CaretLeft',
        route: '/userinfo',
      },
      {//零售交易
        itemname: 'retailsall',
        itemicon: 'Management',
        route: '/retailsall-sale',
      },
      {//日前交易
        itemname: 'daytrade',
        itemicon: 'Management',
        route: '/daytrade-sale',
      },
      {//中长期交易
        itemname: 'longtrade',
        itemicon: 'Ticket',
        route: '/longtrade-sale',
      },
      {//交易结算
        itemname: 'tradesettl',
        itemicon: 'Checked',
        route: '/tradesettl-sale',
      },
      {//交易排名
        itemname: 'tradelists',
        itemicon: 'TrendCharts',
        route: '/tradelists-sale',
      },
      {//现货披露信息
        itemname: 'spotsinfos',
        itemicon: 'List',
        route: '/spotsinfos-sale',
      }
    ];
    const mainMenu = [
      {//用户信息
        itemname: 'userinfo',
        itemicon: 'Avatar',
        route: '/userinfo',
      },
      {//校色管理
        itemname: 'rolemana',
        itemicon: 'VideoCameraFilled',
        route: '/rolemana',
      },
      {//创建校色
        itemname: 'createrole',
        itemicon: 'Flag',
        route: '/createrole',
      },
      {//主题管理
        itemname: 'thememanager',
        itemicon: 'BrushFilled',
        route: '/theme',
      }
    ];
    const rmapMenu = new Map<string, any[]>([
      ['/userinfo', mainMenu],
      ['/rolemana', mainMenu],
      ['/createrole', mainMenu],
      ['/daytrade', tradMenu],
      ['/longtrade', tradMenu],
      ['/tradesettl', tradMenu],
      ['/tradelists', tradMenu],
      ['/spotsinfos', tradMenu],
      ['/retailsall-sale', saleMenu],
      ['/daytrade-sale', saleMenu],
      ['/longtrade-sale', saleMenu],
      ['/tradesettl-sale', saleMenu],
      ['/tradelists-sale', saleMenu],
      ['/spotsinfos-sale', saleMenu]
    ]);

    return {
      collapse: false,
      menuIndx: [] as any[],
      mainMenu,
      tradMenu,
      saleMenu,
      rmapMenu
    };
  },
  getters: {
    sidemenu: (state) => {
      const t = i18n.global.t;
      const processMenu = (menu) => {
        return menu.map(item => ({
          ...item,
          itemtitle: t(item.itemname),
          children: item.children ? processMenu(item.children) : undefined
        }));
      };
      return processMenu(state.menuIndx);
    }
  },
  actions: {
    handleCollapse() {
      this.collapse = !this.collapse;
    },
    setMenuByRoute(routePath: string) {
      const menu = this.rmapMenu.get(routePath);
      debugger
      if (menu) {
        this.menuIndx = menu;
      } else {
        this.menuIndx = [];
      }
    }
  }
});