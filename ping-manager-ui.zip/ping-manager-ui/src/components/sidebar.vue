<template>
  <div class="sidebar-page">
    <el-menu
      class="sidebar-page-menu"
      :default-active="onRoutes"
      :collapse="sidebar.collapse"
      :default-openeds="['1']"
      router
    >
      <template v-for="(menu, index) in sidebar.sidemenu" :key="index">
        <el-menu-item v-if="menu.route" :index="menu.route">
          <el-icon v-if="menu.itemicon">
            <component :is="menu.itemicon" />
          </el-icon>
          <span>{{ menu.itemtitle }}</span>
        </el-menu-item>
        <el-sub-menu v-else :index="String(index)">
          <template #title>
            <el-icon>
              <Menu />
            </el-icon>
            <span>{{ menu.itemtitle }}</span>
          </template>
          <el-menu-item
            v-for="(child, subIndex) in menu.children"
            :key="subIndex"
            :index="child.route"
          >
            <el-icon v-if="child.itemicon">
              <component :is="child.itemicon" />
            </el-icon>
            <span>{{ child.itemtitle }}</span>
          </el-menu-item>
        </el-sub-menu>
      </template>
    </el-menu>
  </div>
</template>
<script setup lang="ts">

/**
 * Copyright 2025 bbcdabao Team
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { computed, watch, onMounted } from 'vue';
import { useSidebarStore } from '@/store/sidebar';
import { ElMenu } from 'element-plus';
import { useRoute } from 'vue-router';

const route = useRoute();
const onRoutes = computed(() => {
  return route.path;
});

const sidebar = useSidebarStore();

const updateMenu = (path: string) => {
  sidebar.setMenuByRoute(path); 
};

onMounted(() => {
  updateMenu(route.path);
});

watch(() => route.path, (newPath) => {
  updateMenu(newPath);
});
</script>
<style scoped>
.sidebar-page {
  width: calc(var(--sidebar-width) + 1px);;
  height: 100%;
}
.sidebar-page-menu:not(.el-menu--collapse) {
  width: auto;
}
.sidebar-page-menu {
  min-height: 100%;
  background-color: var(--sidebar-bg-color);
}
.el-menu-item.is-active {
  font-size: 14px;
  font-weight: bold !important;
  color: var(--sidebar-index-color) !important;
  background-color: var(--sidebar-index-bg-color) !important;
}
.el-menu-item.is-active::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 8px;
  height: 100%;
  background-color: var(--sidebar-index-before-color);
  border-radius: 0 8px 8px 0;
}
.el-menu-item {
  font-size: 14px;
  color: var(--sidebar-color) !important;
  background-color: var(--sidebar-bg-color) !important;
}
.el-menu-item:hover {
  font-size: 14px;
  color: var(--sidebar-index-color) !important;
  background-color: var(--sidebar-index-bg-color) !important;
}
.el-sub-menu {
  font-size: 14px;
  color: var(--sidebar-color) !important;
  background-color: var(--sidebar-bg-color) !important;
}
:deep(.el-sub-menu__title) {
  color: var(--sidebar-color);
}
:deep(.el-sub-menu__title:hover) {
  color: var(--sidebar-color);
  background-color: var(--sidebar-bg-color) !important;
}
</style>